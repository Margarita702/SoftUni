﻿namespace Bakery.Core
{
    internal interface IBakedFoods
    {
    }
}